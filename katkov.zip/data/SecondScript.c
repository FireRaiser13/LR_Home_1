SecondScript()
{

	web_set_sockets_option("SSL_VERSION", "2&3");

	web_add_header("Sec-Fetch-Site", 
		"none");

	web_add_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("DNT", 
		"1");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("WebTours", 
		"URL=http://localhost:1080/WebTours/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("REVEL_FLASH=; DOMAIN=proxyforfrigate.com");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"cross-site");

	web_url("proxy", 
		"URL=https://proxyforfrigate.com/api/2/ru/proxy", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		LAST);

	web_url("settings", 
		"URL=https://frigateblocklist.com/settings?s=814&ins=1562957383.487&ver=3.0.12", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t26.inf", 
		"Mode=HTML", 
		LAST);

	web_url("settings_2", 
		"URL=https://frigateblocklist.com/settings?s=1814&ins=1562957383.487&ver=3.0.12", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t27.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("HSID=ANNeIzw9nKgFOYUU8; DOMAIN=accounts.google.com");

	web_add_cookie("SSID=A6jFZe0M_oo5kS85b; DOMAIN=accounts.google.com");

	web_add_cookie("APISID=VhJyMt6mgYSzInk4/AVkstl9LIglSQydKd; DOMAIN=accounts.google.com");

	web_add_cookie("SAPISID=c5gZ7nWPOMm00a_w/An6Xn9hH2-L7Kj1Ut; DOMAIN=accounts.google.com");

	web_add_cookie("ACCOUNT_CHOOSER=AFx_qI6HUEWVR8R8PDcugQ8v_8kT1KxWtJv_GQ4BRAf9KvlVcrAkgju1NcwTO0yt2ET_mdVY2pcRHss7vL53U_6GkX1JP--K3i7Bx-BTjmepLLiOrXdEaoPWrtZsb1lcUd4o4459FREVtfXEZBiLFp31tMuY-fP0og; DOMAIN=accounts.google.com");

	web_add_cookie("SEARCH_SAMESITE=CgQIvo0B; DOMAIN=accounts.google.com");

	web_add_cookie("LSOLH=491pdS67f30e4Ij4dGh72Gefsmmc3RY:26188627:fbd9; DOMAIN=accounts.google.com");

	web_add_cookie("LSID=doritos|lso|mail|o.calendar.google.com|o.mail.google.com|o.myaccount.google.com|o.notifications.google.com|o.smartlock.google.com|o.takeout.google.com|s.RU|s.youtube|ss|wise:ygUdpSSSXk2h7ssnHMGW_b56ATadtRf-KFz8Y8c-6QAML8GiSXOWzTTb9I-uXKMb1f7PHg.; DOMAIN=accounts.google.com");

	web_add_cookie("GAPS=1:SHJdLYSTRwKvUlMUD0ZgdqDA8Yjo7yrJixiYxp2Mkx-Y_rX2-HteoCeaNEiYOz3NP6PjO0v-Xu6CXk9Tvkv6MX-yeVyaMQ:cSG6TpqAh74I8eSs; DOMAIN=accounts.google.com");

	web_add_cookie("SID=rAcdpQxq631CXX4pVXFVx82V_boF6WR_R7fhSDV7hY7SWFI4D-144hb7ykjEwoKj6-awsg.; DOMAIN=accounts.google.com");

	web_add_cookie("1P_JAR=2019-12-9-16; DOMAIN=accounts.google.com");

	web_add_cookie("NID=193=I_V7rJ1Vt2QOpvHylZM0kegIVL-cHUTz7G4CoXnuLOlFZYJIeBN33HHQd-Eonq2lc0cxmaZh2eMaV55UtPTK8e77NACwsEKTd_bqxjBycn5Z71i-GztG1p1I9pLQiwqnn_7_FooOejYExg_kI1APzZFPHSNN41UuZvvWBSz2K7RAWP-BrLyuESaYeLAkTlYAdTbMM94V2rCLP39x2kxR7KdciLwpVHC8Q9E_F6JXspd6hW1p; DOMAIN=accounts.google.com");

	web_add_cookie("SIDCC=AN0-TYthQ20xjLP209ZoKiS48UxcTnvLMlt_rWby4BGAAy2mRlWQLh8CP-iTsdXu9qlZMzUnNVw; DOMAIN=accounts.google.com");

	web_revert_auto_header("DNT");

	web_add_header("Origin", 
		"https://www.google.com");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_custom_request("ListAccounts", 
		"URL=https://accounts.google.com/ListAccounts?gpsia=1&source=ChromiumBrowser&json=standard", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		"Body= ", 
		LAST);

	/*Possible OAUTH authorization was detected. It is recommended to correlate the authorization parameters.*/

	web_custom_request("token", 
		"URL=https://www.googleapis.com/oauth2/v4/token", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t29.inf", 
		"Mode=HTML", 
		"Body=client_id=77185425430.apps.googleusercontent.com&client_secret=OTJgUOQcT7lO7GsGZq2G4IlT&grant_type=refresh_token&refresh_token=1/BI0fHZbXf8faKrvRBVy28g9HP_pwnRMkZElY6QQ9g7E&scope=https://www.googleapis.com/auth/chromesync", 
		LAST);

	web_url("bins.json", 
		"URL=https://www.gstatic.com/autofill/hourly/bins.json", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t30.inf", 
		"Mode=HTML", 
		LAST);

	web_url("merchants.json", 
		"URL=https://www.gstatic.com/autofill/weekly/merchants.json", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t31.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("A-IM", 
		"x-bm,gzip");

	web_url("seed", 
		"URL=https://clientservices.googleapis.com/chrome-variations/seed?osname=win&channel=stable&milestone=78", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t32.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"nested-navigate");

	web_add_auto_header("DNT", 
		"1");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("header.html", 
		"URL=http://localhost:1080/WebTours/header.html", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/WebTours/", 
		"Snapshot=t33.inf", 
		"Mode=HTML", 
		LAST);

	web_url("welcome.pl", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?signOff=true", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/WebTours/", 
		"Snapshot=t34.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("DNT");

	web_revert_auto_header("Upgrade-Insecure-Requests");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_custom_request("issuetoken", 
		"URL=https://oauthaccountmanager.googleapis.com/v1/issuetoken", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t35.inf", 
		"Mode=HTML", 
		"Body=force=false&response_type=token&scope=https://www.googleapis.com/auth/calendar.readonly+https://www.googleapis.com/auth/cast-edu-messaging+https://www.googleapis.com/auth/clouddevices+https://www.googleapis.com/auth/hangouts+https://www.googleapis.com/auth/hangouts.readonly+https://www.googleapis.com/auth/meetings+https://www.googleapis.com/auth/plus.peopleapi.readwrite+https://www.googleapis.com/auth/userinfo.email&client_id="
		"919648714761-55j965o0km033psv3i9qls5mo3qtdrb0.apps.googleusercontent.com&origin=pkedcjkdefgpdelpbcmbmeomcjbeemfm&device_id=81dd31e9-f9e0-4af4-90f2-b91229b4c2c4&device_type=chrome&lib_ver=extension", 
		LAST);

	web_add_header("X-Goog-Api-Key", 
		"AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw");

	web_url("query", 
		"URL=https://clients1.google.com/tbproxy/af/query?q=Chc2LjEuMTcxNS4xNDQyL2VuIChHR0xMKRMZTfkiOcFFuDAjLeeNQA4kIy3OQUx6JBQ=", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=text/proto", 
		"Referer=", 
		"Snapshot=t36.inf", 
		LAST);

	web_custom_request("CHES4QEStwFBUEE5MWJIeV9pdjZlYWpoM1dEMUJ0dnZaMDdHbkpZOHBFUGJ0c3VnY0FMWW1fRzdmSjFnOEZWRlE2RUEycHFFdjFKVnN2dWoyZ2w5bE9wNGpZNlVvcVY5SV9OVlBDYTM5QW1nT0RDanZXZWtsSmFZQnRsM3NxWjBpaHRzbm1fNGdRb3N1WkhMMVRvbWNHVy1qMERvSUMybUgzOEFtQ3pSblBhRFRiM2xKYVlwRUt1LWo5ZWw4cmsa", 
		"URL=https://clients4.google.com/invalidation/android/request/CHES4QEStwFBUEE5MWJIeV9pdjZlYWpoM1dEMUJ0dnZaMDdHbkpZOHBFUGJ0c3VnY0FMWW1fRzdmSjFnOEZWRlE2RUEycHFFdjFKVnN2dWoyZ2w5bE9wNGpZNlVvcVY5SV9OVlBDYTM5QW1nT0RDanZXZWtsSmFZQnRsM3NxWjBpaHRzbm1fNGdRb3N1WkhMMVRvbWNHVy1qMERvSUMybUgzOEFtQ3pSblBhRFRiM2xKYVlwRUt1LWo5ZWw4cmsaACoCCAAyH2NvbS5nb29nbGUuY2hyb21lLmludmFsaWRhdGlvbnM", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t37.inf", 
		"Mode=HTML", 
		"EncType=application/x-protobuffer", 
		"BodyBinary=\nY\n\\x06\n\\x04\\x08\\x03\\x10\\x02\\x12%\n\\x06\n\\x04\\x08\\x03\\x10\\x01\\x12\\x12\tO.\\xDA^m\\xB8\\xA0\\xBC\\x11\\xC1ELX\\xA6a?L\\x1A\\x07\\x08\\x8A\"\\x10\\x03\\x18\\x01\\x1A\\x18\\x08\\x00\\x12\\x14\\xDA9\\xA3\\xEE^kK\r2U\\xBF\\xEF\\x95`\\x18\\x90\\xAF\\xD8\\x07\t \\x95\\xEB\\xF3\\x88\\xE2\\x80\\x03(\\x002\\x0118\\x9F\\x082\\x95\\x01\n\\x90\\x01\n\\x07\\x08\\x03\\x10\\xAC\\xA1\\xCD\t\\x12sMozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/"
		"78.0.3904.108 Safari/537.36\\x1A\\x03C++\"\\x0Bchrome-sync \\x01", 
		LAST);

	web_add_header("X-Goog-Update-AppId", 
		"aapocclcgogkmnckokdopfmhonfmgoek,aohghmighlieiainnegkcijnfilokake,apdfllckaahabafndbhieahigkjlhalf,blpcfgokakmgnkcojhhkbfbldkacnbeo,fdmmgilgnpjigdojojpjoooidkmcomcm,felcaaldnbdncclmgdcncolpebgiejap,ghbmnnjooekpmoecnnnilnnbdlolhkhi,gighmmpiobklfepjocnamgkkbiglidom,hdbipekpdpggjaipompnomhccfemaljm,jlhmfgmfgeifomenelglieieghnjghma,lbdmhpkmonokeldelekgfefldfboblbj,lmjegmlicamnimmfhcmpkclmigmmcbeh,mgndgikekgjfcpckkfioiadnlibdjbkf,nmmhkkegccagdldgiimedpiccmgmieda,oapompiieilbchpdikbnngomijbkehmn,"
		"omghfjlpggmjjaagoclmmobgdodcjboh,pjkljhegncpnkpknbcohdijeoejaedia,pkedcjkdefgpdelpbcmbmeomcjbeemfm");

	web_add_header("X-Goog-Update-Interactivity", 
		"bg");

	web_add_header("X-Goog-Update-Updater", 
		"chromecrx-78.0.3904.108");

	web_url("crx", 
		"URL=https://clients2.google.com/service/update2/crx?os=win&arch=x64&os_arch=x86_64&nacl_arch=x86-64&prod=chromecrx&prodchannel=&prodversion=78.0.3904.108&lang=ru&acceptformat=crx3&x=id%3Dmgndgikekgjfcpckkfioiadnlibdjbkf%26v%3D0.0.0.0%26installedby%3Dinternal%26uc&x=id%3Dfdmmgilgnpjigdojojpjoooidkmcomcm%26v%3D0.0.0.0%26installedby%3Dinternal%26uc&x=id%3Daapocclcgogkmnckokdopfmhonfmgoek%26v%3D0.10%26installedby%3Dinternal%26uc&x="
		"id%3Daohghmighlieiainnegkcijnfilokake%26v%3D0.10%26installedby%3Dinternal%26uc&x=id%3Dapdfllckaahabafndbhieahigkjlhalf%26v%3D14.2%26installedby%3Dinternal%26uc&x=id%3Dblpcfgokakmgnkcojhhkbfbldkacnbeo%26v%3D4.2.8%26installedby%3Dinternal%26uc&x=id%3Dfelcaaldnbdncclmgdcncolpebgiejap%26v%3D1.2%26installedby%3Dinternal%26uc&x=id%3Dghbmnnjooekpmoecnnnilnnbdlolhkhi%26v%3D1.7%26installedby%3Dexternal%26uc&x=id%3Dgighmmpiobklfepjocnamgkkbiglidom%26v%3D4.0.2%26installedby%3Dinternal%26uc&x="
		"id%3Dhdbipekpdpggjaipompnomhccfemaljm%26v%3D3.0.12%26installedby%3Dinternal%26uc&x=id%3Djlhmfgmfgeifomenelglieieghnjghma%26v%3D1.5.0%26installedby%3Dinternal%26uc&x=id%3Dlbdmhpkmonokeldelekgfefldfboblbj%26v%3D3.1%26installedby%3Dinternal%26uc&x=id%3Dnmmhkkegccagdldgiimedpiccmgmieda%26v%3D1.0.0.5%26installedby%3Dother%26uc&x=id%3Doapompiieilbchpdikbnngomijbkehmn%26v%3D3.4%26installedby%3Dinternal%26uc&x=id%3Dpjkljhegncpnkpknbcohdijeoejaedia%26v%3D8.2%26installedby%3Dinternal%26uc&x="
		"id%3Dpkedcjkdefgpdelpbcmbmeomcjbeemfm%26v%3D7819.902.0.1%26installedby%3Dother%26uc&x=id%3Dlmjegmlicamnimmfhcmpkclmigmmcbeh%26v%3D3.2%26installedby%3Dexternal%26uc&x=id%3Domghfjlpggmjjaagoclmmobgdodcjboh%26v%3D3.26.1%26installedby%3Dinternal%26uc", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=", 
		"Snapshot=t38.inf", 
		"Mode=HTML", 
		LAST);

	lr_start_transaction("2_Script");

	lr_start_transaction("LOGIN");

	web_add_auto_header("Sec-Fetch-Mode", 
		"nested-navigate");

	web_add_auto_header("DNT", 
		"1");

	web_add_header("Origin", 
		"http://localhost:1080");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	lr_think_time(33);

	web_submit_data("login.pl", 
		"Action=http://localhost:1080/cgi-bin/login.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?in=home", 
		"Snapshot=t39.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=userSession", "Value=127662.316160389zfzzzDApDiHfDQDQQpHicDcf", ENDITEM, 
		"Name=username", "Value=jojo", ENDITEM, 
		"Name=password", "Value=bean", ENDITEM, 
		"Name=login.x", "Value=27", ENDITEM, 
		"Name=login.y", "Value=7", ENDITEM, 
		"Name=JSFormSubmit", "Value=off", ENDITEM, 
		LAST);

	lr_end_transaction("LOGIN",LR_AUTO);

	lr_start_transaction("flights");

	web_revert_auto_header("Sec-Fetch-User");

	web_revert_auto_header("Upgrade-Insecure-Requests");

	lr_think_time(9);

	web_url("Search Flights Button", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?page=search", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=home", 
		"Snapshot=t40.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("flights",LR_AUTO);

	lr_start_transaction("flight info 1prs");

	web_add_header("X-Goog-Api-Key", 
		"AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw");

	web_add_header("Sec-Fetch-Site", 
		"none");

	web_add_header("Sec-Fetch-Mode", 
		"no-cors");

	lr_think_time(64);

	web_url("query_2", 
		"URL=https://clients1.google.com/tbproxy/af/query?q=Chc2LjEuMTcxNS4xNDQyL2VuIChHR0xMKRMZQUJTom3LFQojLVRiKa0kIy17ncSlJCMtHzs5hSQjLdqFmWEkIy2pjkq9JBQ=", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=text/proto", 
		"Referer=", 
		"Snapshot=t41.inf", 
		LAST);

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-Mode", 
		"nested-navigate");

	web_add_header("DNT", 
		"1");

	web_add_header("Origin", 
		"http://localhost:1080");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_submit_data("reservations.pl", 
		"Action=http://localhost:1080/cgi-bin/reservations.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/reservations.pl?page=welcome", 
		"Snapshot=t42.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=advanceDiscount", "Value=0", ENDITEM, 
		"Name=depart", "Value=London", ENDITEM, 
		"Name=departDate", "Value=12/19/2019", ENDITEM, 
		"Name=arrive", "Value=Los Angeles", ENDITEM, 
		"Name=returnDate", "Value=12/22/2019", ENDITEM, 
		"Name=numPassengers", "Value=1", ENDITEM, 
		"Name=roundtrip", "Value=on", ENDITEM, 
		"Name=seatPref", "Value=Aisle", ENDITEM, 
		"Name=seatType", "Value=First", ENDITEM, 
		"Name=findFlights.x", "Value=47", ENDITEM, 
		"Name=findFlights.y", "Value=9", ENDITEM, 
		"Name=.cgifields", "Value=roundtrip", ENDITEM, 
		"Name=.cgifields", "Value=seatType", ENDITEM, 
		"Name=.cgifields", "Value=seatPref", ENDITEM, 
		LAST);

	web_add_header("X-HTTP-Method-Override", 
		"POST");

	web_add_header("Sec-Fetch-Site", 
		"none");

	web_add_header("Sec-Fetch-Mode", 
		"no-cors");

	web_url("threatListUpdates:fetch", 
		"URL=https://safebrowsing.googleapis.com/v4/threatListUpdates:fetch?$req="
		"Ch0KDGdvb2dsZWNocm9tZRINNzguMC4zOTA0LjEwOBopCAUQARobCg0IBRAGGAEiAzAwMTABENjVBxoCGAfOL95qIgQgASACKAEaKQgBEAEaGwoNCAEQBhgBIgMwMDEwARDK5gYaAhgHCshXCSIEIAEgAigBGikIAxABGhsKDQgDEAYYASIDMDAxMAEQx-MGGgIYB6kl2ZciBCABIAIoARopCAcQARobCg0IBxAGGAEiAzAwMTABEL_ABhoCGAefu8_vIgQgASACKAEaJwgBEAEaGQoNCAEQBhgBIgMwMDEwAxAUGgIYB9T8RHEiBCABIAIoAxooCAEQCBoaCg0IARAIGAEiAzAwMTAEEPAYGgIYB1mgECUiBCABIAIoBBonCAkQARoZCg0ICRAGGAEiAzAwMTAGEAIaAhgH430gWyIEIAEgAigGGigIDxABGhoKDQgPEAYYASIDMDAxMAEQjR0aAhgHE8CfoiIEIAEgAigBGicIChAIGh"
		"kKDQgKEAgYASIDMDAxMAEQBRoCGAd7EPrfIgQgASACKAEaJwgJEAEaGQoNCAkQBhgBIgMwMDEwARAXGgIYB-ESTZwiBCABIAIoARooCAgQARoaCg0ICBAGGAEiAzAwMTABELcHGgIYB_gwj_8iBCABIAIoARooCA0QARoaCg0IDRAGGAEiAzAwMTABEIhbGgIYB7QgYU4iBCABIAIoARopCA4QARobCg0IDhAGGAEiAzAwMTABEKrdAhoCGAcRgkXmIgQgASACKAEaJwgQEAEaGQoNCBAQBhgBIgMwMDEwARBxGgIYB1JTWukiBCABIAIoASICCAE=&$ct=application/x-protobuf&key=AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/x-protobuf", 
		"Referer=", 
		"Snapshot=t43.inf", 
		LAST);

	lr_end_transaction("flight info 1prs",LR_AUTO);

	lr_start_transaction("choose flight with back");

	web_add_auto_header("DNT", 
		"1");

	web_add_auto_header("Origin", 
		"http://localhost:1080");

	web_add_auto_header("Sec-Fetch-Mode", 
		"nested-navigate");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	lr_think_time(28);

	web_submit_data("reservations.pl_2", 
		"Action=http://localhost:1080/cgi-bin/reservations.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/reservations.pl", 
		"Snapshot=t44.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=outboundFlight", "Value=232;1370;12/19/2019", ENDITEM, 
		"Name=returnFlight", "Value=321;1291;12/22/2019", ENDITEM, 
		"Name=numPassengers", "Value=1", ENDITEM, 
		"Name=advanceDiscount", "Value=0", ENDITEM, 
		"Name=seatType", "Value=First", ENDITEM, 
		"Name=seatPref", "Value=Aisle", ENDITEM, 
		"Name=reserveFlights.x", "Value=38", ENDITEM, 
		"Name=reserveFlights.y", "Value=1", ENDITEM, 
		LAST);

	lr_end_transaction("choose flight with back",LR_AUTO);

	lr_start_transaction("payments details");

	web_revert_auto_header("Origin");

	web_revert_auto_header("Sec-Fetch-User");

	web_revert_auto_header("Upgrade-Insecure-Requests");

	lr_think_time(29);

	web_submit_data("reservations.pl_3", 
		"Action=http://localhost:1080/cgi-bin/reservations.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/reservations.pl", 
		"Snapshot=t45.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=firstName", "Value=Jojo", ENDITEM, 
		"Name=lastName", "Value=Bean", ENDITEM, 
		"Name=address1", "Value=", ENDITEM, 
		"Name=address2", "Value=", ENDITEM, 
		"Name=pass1", "Value=Jojo Bean", ENDITEM, 
		"Name=creditCard", "Value=123456789", ENDITEM, 
		"Name=expDate", "Value=2019", ENDITEM, 
		"Name=oldCCOption", "Value=", ENDITEM, 
		"Name=numPassengers", "Value=1", ENDITEM, 
		"Name=seatType", "Value=First", ENDITEM, 
		"Name=seatPref", "Value=Aisle", ENDITEM, 
		"Name=outboundFlight", "Value=232;1370;12/19/2019", ENDITEM, 
		"Name=advanceDiscount", "Value=0", ENDITEM, 
		"Name=returnFlight", "Value=321;1291;12/22/2019", ENDITEM, 
		"Name=JSFormSubmit", "Value=off", ENDITEM, 
		"Name=buyFlights.x", "Value=47", ENDITEM, 
		"Name=buyFlights.y", "Value=4", ENDITEM, 
		"Name=.cgifields", "Value=saveCC", ENDITEM, 
		LAST);

	lr_end_transaction("payments details",LR_AUTO);

	lr_start_transaction("sign off");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	lr_think_time(19);

	web_url("welcome.pl_2", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?signOff=1", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=flights", 
		"Snapshot=t46.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("sign off",LR_AUTO);

	lr_end_transaction("2_Script",LR_AUTO);

	return 0;
}