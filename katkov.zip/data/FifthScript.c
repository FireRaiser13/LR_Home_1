FifthScript()
{

	web_set_sockets_option("SSL_VERSION", "2&3");

	web_add_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_header("DNT", 
		"1");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("WebTours", 
		"URL=http://localhost:1080/WebTours/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t116.inf", 
		"Mode=HTML", 
		LAST);

	/*Possible OAUTH authorization was detected. It is recommended to correlate the authorization parameters.*/

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_custom_request("token", 
		"URL=https://www.googleapis.com/oauth2/v4/token", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t117.inf", 
		"Mode=HTML", 
		"Body=client_id=77185425430.apps.googleusercontent.com&client_secret=OTJgUOQcT7lO7GsGZq2G4IlT&grant_type=refresh_token&refresh_token=1/BI0fHZbXf8faKrvRBVy28g9HP_pwnRMkZElY6QQ9g7E", 
		LAST);

	web_custom_request("token_2", 
		"URL=https://www.googleapis.com/oauth2/v4/token", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t118.inf", 
		"Mode=HTML", 
		"Body=client_id=77185425430.apps.googleusercontent.com&client_secret=OTJgUOQcT7lO7GsGZq2G4IlT&grant_type=refresh_token&refresh_token=1/BI0fHZbXf8faKrvRBVy28g9HP_pwnRMkZElY6QQ9g7E&scope=https://www.googleapis.com/auth/userinfo.profile", 
		LAST);

	web_add_header("A-IM", 
		"x-bm,gzip");

	web_url("seed", 
		"URL=https://clientservices.googleapis.com/chrome-variations/seed?osname=win&channel=stable&milestone=78", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t119.inf", 
		"Mode=HTML", 
		LAST);

	web_url("merchants.json", 
		"URL=https://www.gstatic.com/autofill/weekly/merchants.json", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t120.inf", 
		"Mode=HTML", 
		LAST);

	web_url("bins.json", 
		"URL=https://www.gstatic.com/autofill/hourly/bins.json", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t121.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("HSID=ANNeIzw9nKgFOYUU8; DOMAIN=accounts.google.com");

	web_add_cookie("SSID=A6jFZe0M_oo5kS85b; DOMAIN=accounts.google.com");

	web_add_cookie("APISID=VhJyMt6mgYSzInk4/AVkstl9LIglSQydKd; DOMAIN=accounts.google.com");

	web_add_cookie("SAPISID=c5gZ7nWPOMm00a_w/An6Xn9hH2-L7Kj1Ut; DOMAIN=accounts.google.com");

	web_add_cookie("ACCOUNT_CHOOSER=AFx_qI6HUEWVR8R8PDcugQ8v_8kT1KxWtJv_GQ4BRAf9KvlVcrAkgju1NcwTO0yt2ET_mdVY2pcRHss7vL53U_6GkX1JP--K3i7Bx-BTjmepLLiOrXdEaoPWrtZsb1lcUd4o4459FREVtfXEZBiLFp31tMuY-fP0og; DOMAIN=accounts.google.com");

	web_add_cookie("SEARCH_SAMESITE=CgQIvo0B; DOMAIN=accounts.google.com");

	web_add_cookie("LSOLH=491pdS67f30e4Ij4dGh72Gefsmmc3RY:26188627:fbd9; DOMAIN=accounts.google.com");

	web_add_cookie("LSID=doritos|lso|mail|o.calendar.google.com|o.mail.google.com|o.myaccount.google.com|o.notifications.google.com|o.smartlock.google.com|o.takeout.google.com|s.RU|s.youtube|ss|wise:ygUdpSSSXk2h7ssnHMGW_b56ATadtRf-KFz8Y8c-6QAML8GiSXOWzTTb9I-uXKMb1f7PHg.; DOMAIN=accounts.google.com");

	web_add_cookie("GAPS=1:SHJdLYSTRwKvUlMUD0ZgdqDA8Yjo7yrJixiYxp2Mkx-Y_rX2-HteoCeaNEiYOz3NP6PjO0v-Xu6CXk9Tvkv6MX-yeVyaMQ:cSG6TpqAh74I8eSs; DOMAIN=accounts.google.com");

	web_add_cookie("SID=rAcdpQxq631CXX4pVXFVx82V_boF6WR_R7fhSDV7hY7SWFI4D-144hb7ykjEwoKj6-awsg.; DOMAIN=accounts.google.com");

	web_add_cookie("1P_JAR=2019-12-9-16; DOMAIN=accounts.google.com");

	web_add_cookie("NID=193=I_V7rJ1Vt2QOpvHylZM0kegIVL-cHUTz7G4CoXnuLOlFZYJIeBN33HHQd-Eonq2lc0cxmaZh2eMaV55UtPTK8e77NACwsEKTd_bqxjBycn5Z71i-GztG1p1I9pLQiwqnn_7_FooOejYExg_kI1APzZFPHSNN41UuZvvWBSz2K7RAWP-BrLyuESaYeLAkTlYAdTbMM94V2rCLP39x2kxR7KdciLwpVHC8Q9E_F6JXspd6hW1p; DOMAIN=accounts.google.com");

	web_add_cookie("SIDCC=AN0-TYtjam3FcaGG0v6medDFr2VlNUUgP2TWKwOLkUkh6iY6t3XeV0fbqy1V40PaGSjB4P-fn6w; DOMAIN=accounts.google.com");

	web_add_header("Origin", 
		"https://www.google.com");

	web_custom_request("ListAccounts", 
		"URL=https://accounts.google.com/ListAccounts?gpsia=1&source=ChromiumBrowser&json=standard", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t122.inf", 
		"Mode=HTML", 
		"Body= ", 
		LAST);

	web_custom_request("token_3", 
		"URL=https://www.googleapis.com/oauth2/v4/token", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t123.inf", 
		"Mode=HTML", 
		"Body=client_id=77185425430.apps.googleusercontent.com&client_secret=OTJgUOQcT7lO7GsGZq2G4IlT&grant_type=refresh_token&refresh_token=1/BI0fHZbXf8faKrvRBVy28g9HP_pwnRMkZElY6QQ9g7E&scope=https://www.googleapis.com/auth/chromesync", 
		LAST);

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Sec-Fetch-Mode", 
		"nested-navigate");

	web_add_header("DNT", 
		"1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("header.html", 
		"URL=http://localhost:1080/WebTours/header.html", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/WebTours/", 
		"Snapshot=t124.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_url("userinfo", 
		"URL=https://www.googleapis.com/oauth2/v1/userinfo", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t125.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"nested-navigate");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("DNT", 
		"1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("welcome.pl", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?signOff=true", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/WebTours/", 
		"Snapshot=t126.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_custom_request("issuetoken", 
		"URL=https://oauthaccountmanager.googleapis.com/v1/issuetoken", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t127.inf", 
		"Mode=HTML", 
		"Body=force=false&response_type=token&scope=https://www.googleapis.com/auth/calendar.readonly+https://www.googleapis.com/auth/cast-edu-messaging+https://www.googleapis.com/auth/clouddevices+https://www.googleapis.com/auth/hangouts+https://www.googleapis.com/auth/hangouts.readonly+https://www.googleapis.com/auth/meetings+https://www.googleapis.com/auth/plus.peopleapi.readwrite+https://www.googleapis.com/auth/userinfo.email&client_id="
		"919648714761-55j965o0km033psv3i9qls5mo3qtdrb0.apps.googleusercontent.com&origin=pkedcjkdefgpdelpbcmbmeomcjbeemfm&device_id=81dd31e9-f9e0-4af4-90f2-b91229b4c2c4&device_type=chrome&lib_ver=extension", 
		LAST);

	web_add_header("X-Goog-Api-Key", 
		"AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw");

	web_url("query", 
		"URL=https://clients1.google.com/tbproxy/af/query?q=Chc2LjEuMTcxNS4xNDQyL2VuIChHR0xMKRMZTfkiOcFFuDAjLeeNQA4kIy3OQUx6JBQ=", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=text/proto", 
		"Referer=", 
		"Snapshot=t128.inf", 
		LAST);

	web_add_header("X-Goog-Update-AppId", 
		"aapocclcgogkmnckokdopfmhonfmgoek,aohghmighlieiainnegkcijnfilokake,apdfllckaahabafndbhieahigkjlhalf,blpcfgokakmgnkcojhhkbfbldkacnbeo,fdmmgilgnpjigdojojpjoooidkmcomcm,felcaaldnbdncclmgdcncolpebgiejap,ghbmnnjooekpmoecnnnilnnbdlolhkhi,gighmmpiobklfepjocnamgkkbiglidom,jlhmfgmfgeifomenelglieieghnjghma,lbdmhpkmonokeldelekgfefldfboblbj,lmjegmlicamnimmfhcmpkclmigmmcbeh,mgndgikekgjfcpckkfioiadnlibdjbkf,nmmhkkegccagdldgiimedpiccmgmieda,omghfjlpggmjjaagoclmmobgdodcjboh,pjkljhegncpnkpknbcohdijeoejaedia,"
		"pkedcjkdefgpdelpbcmbmeomcjbeemfm");

	web_add_header("X-Goog-Update-Interactivity", 
		"bg");

	web_add_header("X-Goog-Update-Updater", 
		"chromecrx-78.0.3904.108");

	web_url("crx", 
		"URL=https://clients2.google.com/service/update2/crx?os=win&arch=x64&os_arch=x86_64&nacl_arch=x86-64&prod=chromecrx&prodchannel=&prodversion=78.0.3904.108&lang=ru&acceptformat=crx3&x=id%3Dmgndgikekgjfcpckkfioiadnlibdjbkf%26v%3D0.0.0.0%26installedby%3Dinternal%26uc&x=id%3Dfdmmgilgnpjigdojojpjoooidkmcomcm%26v%3D0.0.0.0%26installedby%3Dinternal%26uc&x=id%3Daapocclcgogkmnckokdopfmhonfmgoek%26v%3D0.10%26installedby%3Dinternal%26uc&x="
		"id%3Daohghmighlieiainnegkcijnfilokake%26v%3D0.10%26installedby%3Dinternal%26uc&x=id%3Dapdfllckaahabafndbhieahigkjlhalf%26v%3D14.2%26installedby%3Dinternal%26uc&x=id%3Dblpcfgokakmgnkcojhhkbfbldkacnbeo%26v%3D4.2.8%26installedby%3Dinternal%26uc&x=id%3Dfelcaaldnbdncclmgdcncolpebgiejap%26v%3D1.2%26installedby%3Dinternal%26uc&x=id%3Dghbmnnjooekpmoecnnnilnnbdlolhkhi%26v%3D1.7%26installedby%3Dexternal%26uc&x=id%3Dgighmmpiobklfepjocnamgkkbiglidom%26v%3D4.0.2%26installedby%3Dinternal%26uc&x="
		"id%3Dlbdmhpkmonokeldelekgfefldfboblbj%26v%3D3.1%26installedby%3Dinternal%26uc&x=id%3Dnmmhkkegccagdldgiimedpiccmgmieda%26v%3D1.0.0.5%26installedby%3Dother%26uc&x=id%3Dpjkljhegncpnkpknbcohdijeoejaedia%26v%3D8.2%26installedby%3Dinternal%26uc&x=id%3Dpkedcjkdefgpdelpbcmbmeomcjbeemfm%26v%3D7819.902.0.1%26installedby%3Dother%26uc&x=id%3Djlhmfgmfgeifomenelglieieghnjghma%26v%3D1.5.0%26installedby%3Dinternal%26uc&x=id%3Dlmjegmlicamnimmfhcmpkclmigmmcbeh%26v%3D3.2%26installedby%3Dexternal%26uc&x="
		"id%3Domghfjlpggmjjaagoclmmobgdodcjboh%26v%3D3.26.1%26installedby%3Dinternal%26uc", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=", 
		"Snapshot=t129.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("CHES4QEStwFBUEE5MWJIeV9pdjZlYWpoM1dEMUJ0dnZaMDdHbkpZOHBFUGJ0c3VnY0FMWW1fRzdmSjFnOEZWRlE2RUEycHFFdjFKVnN2dWoyZ2w5bE9wNGpZNlVvcVY5SV9OVlBDYTM5QW1nT0RDanZXZWtsSmFZQnRsM3NxWjBpaHRzbm1fNGdRb3N1WkhMMVRvbWNHVy1qMERvSUMybUgzOEFtQ3pSblBhRFRiM2xKYVlwRUt1LWo5ZWw4cmsa", 
		"URL=https://clients4.google.com/invalidation/android/request/CHES4QEStwFBUEE5MWJIeV9pdjZlYWpoM1dEMUJ0dnZaMDdHbkpZOHBFUGJ0c3VnY0FMWW1fRzdmSjFnOEZWRlE2RUEycHFFdjFKVnN2dWoyZ2w5bE9wNGpZNlVvcVY5SV9OVlBDYTM5QW1nT0RDanZXZWtsSmFZQnRsM3NxWjBpaHRzbm1fNGdRb3N1WkhMMVRvbWNHVy1qMERvSUMybUgzOEFtQ3pSblBhRFRiM2xKYVlwRUt1LWo5ZWw4cmsaACoCCAAyH2NvbS5nb29nbGUuY2hyb21lLmludmFsaWRhdGlvbnM", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t130.inf", 
		"Mode=HTML", 
		"EncType=application/x-protobuffer", 
		"BodyBinary=\nY\n\\x06\n\\x04\\x08\\x03\\x10\\x02\\x12%\n\\x06\n\\x04\\x08\\x03\\x10\\x01\\x12\\x12\tO.\\xDA^m\\xB8\\xA0\\xBC\\x11\\xC1ELX\\xA6a?L\\x1A\\x07\\x08\\x8A\"\\x10\\x03\\x18\\x01\\x1A\\x18\\x08\\x00\\x12\\x14\\xDA9\\xA3\\xEE^kK\r2U\\xBF\\xEF\\x95`\\x18\\x90\\xAF\\xD8\\x07\t \\x83\\xDD\\xB7\\x90\\xE2\\x80\\x03(\\x002\\x0118\\x9F\\x082\\x95\\x01\n\\x90\\x01\n\\x07\\x08\\x03\\x10\\xAC\\xA1\\xCD\t\\x12sMozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/"
		"78.0.3904.108 Safari/537.36\\x1A\\x03C++\"\\x0Bchrome-sync \\x01", 
		LAST);

	lr_start_transaction("5_Script");

	lr_start_transaction("LOGIN");

	web_add_auto_header("Sec-Fetch-Mode", 
		"nested-navigate");

	web_add_header("DNT", 
		"1");

	web_add_header("Origin", 
		"http://localhost:1080");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	lr_think_time(21);

	web_submit_data("login.pl", 
		"Action=http://localhost:1080/cgi-bin/login.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?in=home", 
		"Snapshot=t131.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=userSession", "Value=127663.595220737zfzzzQzpVHQVzzzHDQtAApVHHAHf", ENDITEM, 
		"Name=username", "Value=jojo", ENDITEM, 
		"Name=password", "Value=bean", ENDITEM, 
		"Name=login.x", "Value=55", ENDITEM, 
		"Name=login.y", "Value=8", ENDITEM, 
		"Name=JSFormSubmit", "Value=off", ENDITEM, 
		LAST);

	lr_end_transaction("LOGIN",LR_AUTO);

	lr_start_transaction("flights");

	web_add_auto_header("Sec-Fetch-Mode", 
		"nested-navigate");

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("DNT", 
		"1");

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	lr_think_time(86);

	web_url("welcome.pl_2", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?page=search", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=home", 
		"Snapshot=t133.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("X-Goog-Api-Key", 
		"AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw");

	web_add_header("Sec-Fetch-Site", 
		"none");

	web_url("query_2", 
		"URL=https://clients1.google.com/tbproxy/af/query?q=Chc2LjEuMTcxNS4xNDQyL2VuIChHR0xMKRMZQUJTom3LFQojLVRiKa0kIy17ncSlJCMtHzs5hSQjLdqFmWEkIy2pjkq9JBQ=", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=text/proto", 
		"Referer=", 
		"Snapshot=t134.inf", 
		LAST);

	lr_end_transaction("flights",LR_AUTO);

	lr_start_transaction("flight info 3prs");

	web_add_header("Origin", 
		"http://localhost:1080");

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	lr_think_time(39);

	web_submit_data("reservations.pl", 
		"Action=http://localhost:1080/cgi-bin/reservations.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/reservations.pl?page=welcome", 
		"Snapshot=t135.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=advanceDiscount", "Value=0", ENDITEM, 
		"Name=depart", "Value=Los Angeles", ENDITEM, 
		"Name=departDate", "Value=12/18/2019", ENDITEM, 
		"Name=arrive", "Value=Seattle", ENDITEM, 
		"Name=returnDate", "Value=12/18/2019", ENDITEM, 
		"Name=numPassengers", "Value=3", ENDITEM, 
		"Name=seatPref", "Value=Aisle", ENDITEM, 
		"Name=seatType", "Value=Business", ENDITEM, 
		"Name=findFlights.x", "Value=37", ENDITEM, 
		"Name=findFlights.y", "Value=3", ENDITEM, 
		"Name=.cgifields", "Value=roundtrip", ENDITEM, 
		"Name=.cgifields", "Value=seatType", ENDITEM, 
		"Name=.cgifields", "Value=seatPref", ENDITEM, 
		LAST);

	lr_end_transaction("flight info 3prs",LR_AUTO);

	lr_start_transaction("choose flight single");

	web_add_header("DNT", 
		"1");

	web_add_header("Origin", 
		"http://localhost:1080");

	web_add_header("Sec-Fetch-Mode", 
		"nested-navigate");

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	lr_think_time(60);

	web_submit_data("reservations.pl_2", 
		"Action=http://localhost:1080/cgi-bin/reservations.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/reservations.pl", 
		"Snapshot=t136.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=outboundFlight", "Value=372;239;12/18/2019", ENDITEM, 
		"Name=numPassengers", "Value=3", ENDITEM, 
		"Name=advanceDiscount", "Value=0", ENDITEM, 
		"Name=seatType", "Value=Business", ENDITEM, 
		"Name=seatPref", "Value=Aisle", ENDITEM, 
		"Name=reserveFlights.x", "Value=41", ENDITEM, 
		"Name=reserveFlights.y", "Value=5", ENDITEM, 
		LAST);

	lr_end_transaction("choose flight single",LR_AUTO);

	lr_start_transaction("payments details");

	web_add_auto_header("Sec-Fetch-Mode", 
		"nested-navigate");

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("DNT", 
		"1");

	web_add_header("Origin", 
		"http://localhost:1080");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	lr_think_time(46);

	web_submit_data("reservations.pl_3", 
		"Action=http://localhost:1080/cgi-bin/reservations.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/reservations.pl", 
		"Snapshot=t137.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=firstName", "Value=Jojo", ENDITEM, 
		"Name=lastName", "Value=Bean", ENDITEM, 
		"Name=address1", "Value=", ENDITEM, 
		"Name=address2", "Value=", ENDITEM, 
		"Name=pass1", "Value=Jojo Bean", ENDITEM, 
		"Name=pass2", "Value=Pipo Head", ENDITEM, 
		"Name=pass3", "Value=Hoho Tean", ENDITEM, 
		"Name=creditCard", "Value=123456789", ENDITEM, 
		"Name=expDate", "Value=2019", ENDITEM, 
		"Name=oldCCOption", "Value=", ENDITEM, 
		"Name=numPassengers", "Value=3", ENDITEM, 
		"Name=seatType", "Value=Business", ENDITEM, 
		"Name=seatPref", "Value=Aisle", ENDITEM, 
		"Name=outboundFlight", "Value=372;239;12/18/2019", ENDITEM, 
		"Name=advanceDiscount", "Value=0", ENDITEM, 
		"Name=returnFlight", "Value=", ENDITEM, 
		"Name=JSFormSubmit", "Value=off", ENDITEM, 
		"Name=buyFlights.x", "Value=32", ENDITEM, 
		"Name=buyFlights.y", "Value=7", ENDITEM, 
		"Name=.cgifields", "Value=saveCC", ENDITEM, 
		LAST);

	lr_end_transaction("payments details",LR_AUTO);

	lr_start_transaction("sign off");

	web_add_header("Sec-Fetch-Site", 
		"none");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_header("X-Goog-Update-AppId", 
		"ihnlcenocehgdaegdmhbidjhnhdchfmm,mimojjlkmoijpicakmndhoigimigcmbb,hnimpnehoodheedghdeeijklkeaacbdc,oimompecagnajdejgnnjijobebaeigek,hfnkpimlhhgieaddgfemjhofmfblmnib,gcmjkmgdlgnkkcocmoeiminaijmmjnii,llkgjffcdpffmhiakmfcdcblohccpfmo,khaoiebndkojlmppeemjhbpbandiljpe,aemomkdncapdnfajjbbcbdebjljbpmpj,giekcmmlnklenlaomppkphknjmnnpneh,ehgidpndbllacpjalkiimkbadgjfnnmc,gkmgaooipdjhmangpemjhigmamcehddo,jflookgnkcckhobaglndicnbbgbonegd,copjbmjbojbakpaedmpkhmiplmmehfck");

	web_add_header("X-Goog-Update-Interactivity", 
		"bg");

	web_add_header("X-Goog-Update-Updater", 
		"chrome-78.0.3904.108");

	lr_think_time(18);

	web_custom_request("json", 
		"URL=https://update.googleapis.com/service/update2/json?cup2key=9:4062894043&cup2hreq=7cbec3488913cbdb98ad4cd18959ecdd7b91c2369c507f14d8ddbdbdb16461ae", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t138.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chrome\",\"acceptformat\":\"crx2,crx3\",\"app\":[{\"appid\":\"ihnlcenocehgdaegdmhbidjhnhdchfmm\",\"brand\":\"GGLS\",\"cohortname\":\"Auto\",\"enabled\":true,\"ping\":{\"ping_freshness\":\"{fc46c146-34a4-44b4-b3e8-76dbf3e02654}\",\"rd\":4726},\"updatecheck\":{},\"version\":\"0.0.0.0\"},{\"appid\":\"mimojjlkmoijpicakmndhoigimigcmbb\",\"brand\":\"GGLS\",\"cohort\":\"1:d0j:\",\"cohorthint\":\"Chrome [M50... M99]\",\"cohortname\":\"Chrome [M50... M99]\""
		",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.ee0ab2bc3e8f52aac61e7e2085181b1e9125fe311a6c4b3839e5ad35f92da4ec\"}]},\"ping\":{\"ping_freshness\":\"{b25dfcdc-b18f-41a8-9cec-ad5695ca403a}\",\"rd\":4726},\"updatecheck\":{},\"version\":\"32.0.0.303\"},{\"appid\":\"hnimpnehoodheedghdeeijklkeaacbdc\",\"brand\":\"GGLS\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.1cd7dc2056afaa0f6a705c9a17d22bba6578b33f5dae9e2d6518a0bfcced2396\"}]},\"ping\":{\"ping_freshness\":\""
		"{1e731504-3a5e-4d7a-a71f-56c3c54df3fe}\",\"rd\":4726},\"updatecheck\":{},\"version\":\"0.57.44.2492\"},{\"appid\":\"oimompecagnajdejgnnjijobebaeigek\",\"brand\":\"GGLS\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.6527d16e8dda353c6efcebbafb3ee70a6c48e48007743892938f507abd0108a8\"}]},\"ping\":{\"ping_freshness\":\"{7f9d1484-f4e1-42fa-ae9b-779743d70d9e}\",\"rd\":4726},\"updatecheck\":{},\"version\":\"4.10.1582.2\"},{\"appid\":\"hfnkpimlhhgieaddgfemjhofmfblmnib\",\"brand\":\"GGLS\",\""
		"cohort\":\"1:jcl:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.5c6d3312e893f9d3914adc9811db635dfce12a1105823a9d132f637f2a6876e1\"}]},\"ping\":{\"ping_freshness\":\"{17e214a6-bc70-4aec-aa42-61a9735d91d9}\",\"rd\":4726},\"updatecheck\":{},\"version\":\"5564\"},{\"appid\":\"gcmjkmgdlgnkkcocmoeiminaijmmjnii\",\"brand\":\"GGLS\",\"cohort\":\"1:bm1:tzf@0.1\",\"cohorthint\":\"M54ToM99\",\"cohortname\":\"M54ToM99\",\"enabled\":true,\"packages\":"
		"{\"package\":[{\"fp\":\"1.b5b026f77082f5592005f28effcc0f5753779035ac4bb81d9bf15b450b1a64aa\"}]},\"ping\":{\"ping_freshness\":\"{6b5f6098-a644-4b1e-a905-e183b6d2f523}\",\"rd\":4726},\"updatecheck\":{},\"version\":\"9.7.2\"},{\"appid\":\"llkgjffcdpffmhiakmfcdcblohccpfmo\",\"brand\":\"GGLS\",\"enabled\":true,\"ping\":{\"ping_freshness\":\"{3a65a52f-d636-4b3e-8ce2-5d4b7f7f6ca3}\",\"rd\":4726},\"updatecheck\":{},\"version\":\"0.0.0.0\"},{\"appid\":\"khaoiebndkojlmppeemjhbpbandiljpe\",\"brand\":\"GGLS\""
		",\"cohort\":\"1:cux:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.b9fb798d7e88c0fe09c483b54340ac22e0a0a47888231521657a768b0a44cbe9\"}]},\"ping\":{\"ping_freshness\":\"{42f83d2e-4752-46d7-bd57-28e0d16d6407}\",\"rd\":4726},\"updatecheck\":{},\"version\":\"40\"},{\"appid\":\"aemomkdncapdnfajjbbcbdebjljbpmpj\",\"brand\":\"GGLS\",\"enabled\":true,\"ping\":{\"ping_freshness\":\"{7aa13e9f-4ef3-4e26-b57a-ef3cc3edfa39}\",\"rd\":4726},\""
		"updatecheck\":{},\"version\":\"1.0.5.0\"},{\"appid\":\"giekcmmlnklenlaomppkphknjmnnpneh\",\"brand\":\"GGLS\",\"cohort\":\"1:j5l:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.3eb16d6c28b502ac4cfee8f4a148df05f4d93229fa36a71db8b08d06329ff18a\"}]},\"ping\":{\"ping_freshness\":\"{a7b1aa96-a5fb-4119-a41f-2bbbc878730d}\",\"rd\":4726},\"updatecheck\":{},\"version\":\"7\"},{\"appid\":\"ehgidpndbllacpjalkiimkbadgjfnnmc\",\"brand\":\"GGLS\",\""
		"cohort\":\"1:ofl:\",\"cohorthint\":\"stable64\",\"cohortname\":\"stable64\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.a8a79d350c2a5e3bc36226633a8e0bed0dfab184e77f38fc8f0820ebacf8eafc\"}]},\"ping\":{\"ping_freshness\":\"{aa220378-e94d-47c5-bab6-e0501bbf7b27}\",\"rd\":4726},\"updatecheck\":{},\"version\":\"2018.8.8.0\"},{\"appid\":\"gkmgaooipdjhmangpemjhigmamcehddo\",\"brand\":\"GGLS\",\"cohort\":\"1:pw3:\",\"cohorthint\":\"Stable\",\"cohortname\":\"Stable\",\"enabled\":true,\""
		"packages\":{\"package\":[{\"fp\":\"1.42fb53caca4405c3d10e3eb42332865e2fb9a5b1af4c3d58c58cda6441a9ed61\"}]},\"ping\":{\"ping_freshness\":\"{4c342cc5-4f66-499c-8cc5-e5773e2db7b5}\",\"rd\":4726},\"tag\":\"eset_exp_b\",\"updatecheck\":{},\"version\":\"77.224.200\"},{\"appid\":\"jflookgnkcckhobaglndicnbbgbonegd\",\"brand\":\"GGLS\",\"cohort\":\"1:s7x:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\""
		"1.26e121345f713f0e0d25d420a4e9467ffd18c21d1fde094ce514ce64587f2d24\"}]},\"ping\":{\"ping_freshness\":\"{035d2f21-052e-491a-a4bb-10fdb477365c}\",\"rd\":4726},\"updatecheck\":{},\"version\":\"31\"},{\"appid\":\"copjbmjbojbakpaedmpkhmiplmmehfck\",\"brand\":\"GGLS\",\"cohort\":\"1:p1x:\",\"cohorthint\":\"Auto\",\"cohortname\":\"Auto\",\"enabled\":true,\"packages\":{\"package\":[{\"fp\":\"1.207921137eee9c0831e0bd890330986c10dfd9382034491b82de3f86ae6915f7\"}]},\"ping\":{\"ping_freshness\":\""
		"{f258cc7b-c087-43a0-ac2d-5765cd4c81a9}\",\"rd\":4726},\"updatecheck\":{},\"version\":\"2018.9.6.0\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":false,\"hw\":{\"physmemory\":8},\"lang\":\"ru\",\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.17134.1130\"},\"prodversion\":\"78.0.3904.108\",\"protocol\":\"3.1\",\"requestid\":\"{9bde7037-a9f7-46a8-a74c-848a4d2ad101}\",\"sessionid\":\"{9c4df7e0-75e9-43ac-9590-be74893d841b}\",\"updater\":{\""
		"autoupdatecheckenabled\":true,\"ismachine\":true,\"lastchecked\":0,\"laststarted\":0,\"name\":\"Omaha\",\"updatepolicy\":-1,\"version\":\"1.3.35.342\"},\"updaterversion\":\"78.0.3904.108\"}}", 
		LAST);

	web_add_header("DNT", 
		"1");

	web_add_auto_header("Sec-Fetch-Mode", 
		"nested-navigate");

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("welcome.pl_3", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?signOff=1", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=flights", 
		"Snapshot=t139.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("sign off",LR_AUTO);

	lr_end_transaction("5_Script",LR_AUTO);

	return 0;
}