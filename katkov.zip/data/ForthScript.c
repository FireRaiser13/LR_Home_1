ForthScript()
{

	web_add_auto_header("DNT", 
		"1");

	web_add_header("Origin", 
		"chrome-extension://lbdmhpkmonokeldelekgfefldfboblbj");

	web_url("v1", 
		"URL=http://nrtk.rmcontrol.net/api/v1/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t93.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("SSL_VERSION", "2&3");

	web_add_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	lr_think_time(7);

	web_url("WebTours", 
		"URL=http://localhost:1080/WebTours/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t94.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("DNT");

	web_add_header("A-IM", 
		"x-bm,gzip");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_url("seed", 
		"URL=https://clientservices.googleapis.com/chrome-variations/seed?osname=win&channel=stable&milestone=78", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t95.inf", 
		"Mode=HTML", 
		LAST);

	web_url("merchants.json", 
		"URL=https://www.gstatic.com/autofill/weekly/merchants.json", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t96.inf", 
		"Mode=HTML", 
		LAST);

	web_url("bins.json", 
		"URL=https://www.gstatic.com/autofill/hourly/bins.json", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t97.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("HSID=ANNeIzw9nKgFOYUU8; DOMAIN=accounts.google.com");

	web_add_cookie("SSID=A6jFZe0M_oo5kS85b; DOMAIN=accounts.google.com");

	web_add_cookie("APISID=VhJyMt6mgYSzInk4/AVkstl9LIglSQydKd; DOMAIN=accounts.google.com");

	web_add_cookie("SAPISID=c5gZ7nWPOMm00a_w/An6Xn9hH2-L7Kj1Ut; DOMAIN=accounts.google.com");

	web_add_cookie("ACCOUNT_CHOOSER=AFx_qI6HUEWVR8R8PDcugQ8v_8kT1KxWtJv_GQ4BRAf9KvlVcrAkgju1NcwTO0yt2ET_mdVY2pcRHss7vL53U_6GkX1JP--K3i7Bx-BTjmepLLiOrXdEaoPWrtZsb1lcUd4o4459FREVtfXEZBiLFp31tMuY-fP0og; DOMAIN=accounts.google.com");

	web_add_cookie("SEARCH_SAMESITE=CgQIvo0B; DOMAIN=accounts.google.com");

	web_add_cookie("LSOLH=491pdS67f30e4Ij4dGh72Gefsmmc3RY:26188627:fbd9; DOMAIN=accounts.google.com");

	web_add_cookie("LSID=doritos|lso|mail|o.calendar.google.com|o.mail.google.com|o.myaccount.google.com|o.notifications.google.com|o.smartlock.google.com|o.takeout.google.com|s.RU|s.youtube|ss|wise:ygUdpSSSXk2h7ssnHMGW_b56ATadtRf-KFz8Y8c-6QAML8GiSXOWzTTb9I-uXKMb1f7PHg.; DOMAIN=accounts.google.com");

	web_add_cookie("GAPS=1:SHJdLYSTRwKvUlMUD0ZgdqDA8Yjo7yrJixiYxp2Mkx-Y_rX2-HteoCeaNEiYOz3NP6PjO0v-Xu6CXk9Tvkv6MX-yeVyaMQ:cSG6TpqAh74I8eSs; DOMAIN=accounts.google.com");

	web_add_cookie("SID=rAcdpQxq631CXX4pVXFVx82V_boF6WR_R7fhSDV7hY7SWFI4D-144hb7ykjEwoKj6-awsg.; DOMAIN=accounts.google.com");

	web_add_cookie("1P_JAR=2019-12-9-16; DOMAIN=accounts.google.com");

	web_add_cookie("NID=193=I_V7rJ1Vt2QOpvHylZM0kegIVL-cHUTz7G4CoXnuLOlFZYJIeBN33HHQd-Eonq2lc0cxmaZh2eMaV55UtPTK8e77NACwsEKTd_bqxjBycn5Z71i-GztG1p1I9pLQiwqnn_7_FooOejYExg_kI1APzZFPHSNN41UuZvvWBSz2K7RAWP-BrLyuESaYeLAkTlYAdTbMM94V2rCLP39x2kxR7KdciLwpVHC8Q9E_F6JXspd6hW1p; DOMAIN=accounts.google.com");

	web_add_cookie("SIDCC=AN0-TYtcIe9Uv5Y8mPHCsXuMXo1YAUa5QCvlK9JQBk3BBM1sy5Ug6YlQUVuz_AD9eRobZjNN4vI; DOMAIN=accounts.google.com");

	web_add_header("Origin", 
		"https://www.google.com");

	web_custom_request("ListAccounts", 
		"URL=https://accounts.google.com/ListAccounts?gpsia=1&source=ChromiumBrowser&json=standard", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t98.inf", 
		"Mode=HTML", 
		"Body= ", 
		LAST);

	/*Possible OAUTH authorization was detected. It is recommended to correlate the authorization parameters.*/

	web_custom_request("token", 
		"URL=https://www.googleapis.com/oauth2/v4/token", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t99.inf", 
		"Mode=HTML", 
		"Body=client_id=77185425430.apps.googleusercontent.com&client_secret=OTJgUOQcT7lO7GsGZq2G4IlT&grant_type=refresh_token&refresh_token=1/BI0fHZbXf8faKrvRBVy28g9HP_pwnRMkZElY6QQ9g7E", 
		LAST);

	web_custom_request("token_2", 
		"URL=https://www.googleapis.com/oauth2/v4/token", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t100.inf", 
		"Mode=HTML", 
		"Body=client_id=77185425430.apps.googleusercontent.com&client_secret=OTJgUOQcT7lO7GsGZq2G4IlT&grant_type=refresh_token&refresh_token=1/BI0fHZbXf8faKrvRBVy28g9HP_pwnRMkZElY6QQ9g7E&scope=https://www.googleapis.com/auth/userinfo.profile", 
		LAST);

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Sec-Fetch-Mode", 
		"nested-navigate");

	web_add_header("DNT", 
		"1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("header.html", 
		"URL=http://localhost:1080/WebTours/header.html", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/WebTours/", 
		"Snapshot=t101.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_custom_request("token_3", 
		"URL=https://www.googleapis.com/oauth2/v4/token", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t102.inf", 
		"Mode=HTML", 
		"Body=client_id=77185425430.apps.googleusercontent.com&client_secret=OTJgUOQcT7lO7GsGZq2G4IlT&grant_type=refresh_token&refresh_token=1/BI0fHZbXf8faKrvRBVy28g9HP_pwnRMkZElY6QQ9g7E&scope=https://www.googleapis.com/auth/chromesync", 
		LAST);

	web_url("userinfo", 
		"URL=https://www.googleapis.com/oauth2/v1/userinfo", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t103.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"nested-navigate");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("DNT", 
		"1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("welcome.pl", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?signOff=true", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/WebTours/", 
		"Snapshot=t104.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_custom_request("issuetoken", 
		"URL=https://oauthaccountmanager.googleapis.com/v1/issuetoken", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t105.inf", 
		"Mode=HTML", 
		"Body=force=false&response_type=token&scope=https://www.googleapis.com/auth/calendar.readonly+https://www.googleapis.com/auth/cast-edu-messaging+https://www.googleapis.com/auth/clouddevices+https://www.googleapis.com/auth/hangouts+https://www.googleapis.com/auth/hangouts.readonly+https://www.googleapis.com/auth/meetings+https://www.googleapis.com/auth/plus.peopleapi.readwrite+https://www.googleapis.com/auth/userinfo.email&client_id="
		"919648714761-55j965o0km033psv3i9qls5mo3qtdrb0.apps.googleusercontent.com&origin=pkedcjkdefgpdelpbcmbmeomcjbeemfm&device_id=81dd31e9-f9e0-4af4-90f2-b91229b4c2c4&device_type=chrome&lib_ver=extension", 
		LAST);

	web_add_header("X-Goog-Api-Key", 
		"AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw");

	web_url("query", 
		"URL=https://clients1.google.com/tbproxy/af/query?q=Chc2LjEuMTcxNS4xNDQyL2VuIChHR0xMKRMZTfkiOcFFuDAjLeeNQA4kIy3OQUx6JBQ=", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=text/proto", 
		"Referer=", 
		"Snapshot=t106.inf", 
		LAST);

	web_custom_request("token_4", 
		"URL=https://www.googleapis.com/oauth2/v4/token", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t107.inf", 
		"Mode=HTML", 
		"Body=client_id=77185425430.apps.googleusercontent.com&client_secret=OTJgUOQcT7lO7GsGZq2G4IlT&grant_type=refresh_token&refresh_token=1/BI0fHZbXf8faKrvRBVy28g9HP_pwnRMkZElY6QQ9g7E&scope=https://www.googleapis.com/auth/firebase.messaging", 
		LAST);

	web_add_header("X-Goog-Update-AppId", 
		"aapocclcgogkmnckokdopfmhonfmgoek,aohghmighlieiainnegkcijnfilokake,apdfllckaahabafndbhieahigkjlhalf,blpcfgokakmgnkcojhhkbfbldkacnbeo,fdmmgilgnpjigdojojpjoooidkmcomcm,felcaaldnbdncclmgdcncolpebgiejap,ghbmnnjooekpmoecnnnilnnbdlolhkhi,gighmmpiobklfepjocnamgkkbiglidom,jlhmfgmfgeifomenelglieieghnjghma,lbdmhpkmonokeldelekgfefldfboblbj,lmjegmlicamnimmfhcmpkclmigmmcbeh,mgndgikekgjfcpckkfioiadnlibdjbkf,nmmhkkegccagdldgiimedpiccmgmieda,omghfjlpggmjjaagoclmmobgdodcjboh,pjkljhegncpnkpknbcohdijeoejaedia,"
		"pkedcjkdefgpdelpbcmbmeomcjbeemfm");

	web_add_header("X-Goog-Update-Interactivity", 
		"bg");

	web_add_header("X-Goog-Update-Updater", 
		"chromecrx-78.0.3904.108");

	web_url("crx", 
		"URL=https://clients2.google.com/service/update2/crx?os=win&arch=x64&os_arch=x86_64&nacl_arch=x86-64&prod=chromecrx&prodchannel=&prodversion=78.0.3904.108&lang=ru&acceptformat=crx3&x=id%3Dmgndgikekgjfcpckkfioiadnlibdjbkf%26v%3D0.0.0.0%26installedby%3Dinternal%26uc&x=id%3Dfdmmgilgnpjigdojojpjoooidkmcomcm%26v%3D0.0.0.0%26installedby%3Dinternal%26uc&x=id%3Daapocclcgogkmnckokdopfmhonfmgoek%26v%3D0.10%26installedby%3Dinternal%26uc&x="
		"id%3Daohghmighlieiainnegkcijnfilokake%26v%3D0.10%26installedby%3Dinternal%26uc&x=id%3Dapdfllckaahabafndbhieahigkjlhalf%26v%3D14.2%26installedby%3Dinternal%26uc&x=id%3Dblpcfgokakmgnkcojhhkbfbldkacnbeo%26v%3D4.2.8%26installedby%3Dinternal%26uc&x=id%3Dfelcaaldnbdncclmgdcncolpebgiejap%26v%3D1.2%26installedby%3Dinternal%26uc&x=id%3Dghbmnnjooekpmoecnnnilnnbdlolhkhi%26v%3D1.7%26installedby%3Dexternal%26uc&x=id%3Dgighmmpiobklfepjocnamgkkbiglidom%26v%3D4.0.2%26installedby%3Dinternal%26uc&x="
		"id%3Dlbdmhpkmonokeldelekgfefldfboblbj%26v%3D3.1%26installedby%3Dinternal%26uc&x=id%3Dnmmhkkegccagdldgiimedpiccmgmieda%26v%3D1.0.0.5%26installedby%3Dother%26uc&x=id%3Dpjkljhegncpnkpknbcohdijeoejaedia%26v%3D8.2%26installedby%3Dinternal%26uc&x=id%3Dpkedcjkdefgpdelpbcmbmeomcjbeemfm%26v%3D7819.902.0.1%26installedby%3Dother%26uc&x=id%3Djlhmfgmfgeifomenelglieieghnjghma%26v%3D1.5.0%26installedby%3Dinternal%26uc&x=id%3Dlmjegmlicamnimmfhcmpkclmigmmcbeh%26v%3D3.2%26installedby%3Dexternal%26uc&x="
		"id%3Domghfjlpggmjjaagoclmmobgdodcjboh%26v%3D3.26.1%26installedby%3Dinternal%26uc", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=", 
		"Snapshot=t108.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("CHES4QEStwFBUEE5MWJIeV9pdjZlYWpoM1dEMUJ0dnZaMDdHbkpZOHBFUGJ0c3VnY0FMWW1fRzdmSjFnOEZWRlE2RUEycHFFdjFKVnN2dWoyZ2w5bE9wNGpZNlVvcVY5SV9OVlBDYTM5QW1nT0RDanZXZWtsSmFZQnRsM3NxWjBpaHRzbm1fNGdRb3N1WkhMMVRvbWNHVy1qMERvSUMybUgzOEFtQ3pSblBhRFRiM2xKYVlwRUt1LWo5ZWw4cmsa", 
		"URL=https://clients4.google.com/invalidation/android/request/CHES4QEStwFBUEE5MWJIeV9pdjZlYWpoM1dEMUJ0dnZaMDdHbkpZOHBFUGJ0c3VnY0FMWW1fRzdmSjFnOEZWRlE2RUEycHFFdjFKVnN2dWoyZ2w5bE9wNGpZNlVvcVY5SV9OVlBDYTM5QW1nT0RDanZXZWtsSmFZQnRsM3NxWjBpaHRzbm1fNGdRb3N1WkhMMVRvbWNHVy1qMERvSUMybUgzOEFtQ3pSblBhRFRiM2xKYVlwRUt1LWo5ZWw4cmsaACoCCAAyH2NvbS5nb29nbGUuY2hyb21lLmludmFsaWRhdGlvbnM", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t109.inf", 
		"Mode=HTML", 
		"EncType=application/x-protobuffer", 
		"BodyBinary=\nY\n\\x06\n\\x04\\x08\\x03\\x10\\x02\\x12%\n\\x06\n\\x04\\x08\\x03\\x10\\x01\\x12\\x12\tO.\\xDA^m\\xB8\\xA0\\xBC\\x11\\xC1ELX\\xA6a?L\\x1A\\x07\\x08\\x8A\"\\x10\\x03\\x18\\x01\\x1A\\x18\\x08\\x00\\x12\\x14\\xDA9\\xA3\\xEE^kK\r2U\\xBF\\xEF\\x95`\\x18\\x90\\xAF\\xD8\\x07\t \\xF8\\x95\\xF2\\x8F\\xE2\\x80\\x03(\\x002\\x0118\\x9F\\x082\\x95\\x01\n\\x90\\x01\n\\x07\\x08\\x03\\x10\\xAC\\xA1\\xCD\t\\x12sMozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/"
		"78.0.3904.108 Safari/537.36\\x1A\\x03C++\"\\x0Bchrome-sync \\x01", 
		LAST);

	lr_start_transaction("4_Script");

	lr_start_transaction("LOGIN");

	web_add_auto_header("Sec-Fetch-Mode", 
		"nested-navigate");

	web_add_auto_header("DNT", 
		"1");

	web_add_header("Origin", 
		"http://localhost:1080");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	lr_think_time(18);

	web_submit_data("login.pl", 
		"Action=http://localhost:1080/cgi-bin/login.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?in=home", 
		"Snapshot=t110.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=userSession", "Value=127663.502875658zfzzzQVptcQVzzzHDQtAApVtifHf", ENDITEM, 
		"Name=username", "Value=jojo", ENDITEM, 
		"Name=password", "Value=bean", ENDITEM, 
		"Name=login.x", "Value=75", ENDITEM, 
		"Name=login.y", "Value=10", ENDITEM, 
		"Name=JSFormSubmit", "Value=off", ENDITEM, 
		LAST);

	lr_end_transaction("LOGIN",LR_AUTO);

	lr_start_transaction("home");

	web_revert_auto_header("Sec-Fetch-User");

	lr_think_time(8);

	web_url("Home Button", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?page=menus", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=home", 
		"Snapshot=t111.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("home",LR_AUTO);

	lr_start_transaction("itinerary");

	web_add_auto_header("Sec-Fetch-Mode", 
		"nested-navigate");

	web_add_header("DNT", 
		"1");

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	lr_think_time(24);

	web_url("welcome.pl_2", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?page=itinerary", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=home", 
		"Snapshot=t112.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("itinerary",LR_AUTO);

	lr_start_transaction("itinerary cancel");

	web_add_auto_header("DNT", 
		"1");

	web_add_auto_header("Origin", 
		"http://localhost:1080");

	web_add_auto_header("Sec-Fetch-Mode", 
		"nested-navigate");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Sec-Fetch-User", 
		"?1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	lr_think_time(39);

	web_submit_data("itinerary.pl", 
		"Action=http://localhost:1080/cgi-bin/itinerary.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/itinerary.pl", 
		"Snapshot=t113.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=1", "Value=on", ENDITEM, 
		"Name=flightID", "Value=251445271-793-JB", ENDITEM, 
		"Name=flightID", "Value=251445276-1693988-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-2315-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-3085-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-3854-JB", ENDITEM, 
		"Name=flightID", "Value=2514530421-4862512-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-5392-JB", ENDITEM, 
		"Name=flightID", "Value=2514622660-6801831-JB", ENDITEM, 
		"Name=flightID", "Value=25146569-698-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-7700-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-8469-JB", ENDITEM, 
		"Name=flightID", "Value=2514530421-9477897-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-10008-JB", ENDITEM, 
		"Name=flightID", "Value=2514530421-11016358-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-11546-JB", ENDITEM, 
		"Name=flightID", "Value=2514530421-12554820-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-13085-JB", ENDITEM, 
		"Name=flightID", "Value=2514530421-14093281-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-14623-JB", ENDITEM, 
		"Name=flightID", "Value=2514530421-15631743-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-16162-JB", ENDITEM, 
		"Name=flightID", "Value=2514530421-17170204-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-17700-JB", ENDITEM, 
		"Name=flightID", "Value=2514530421-18708666-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-19239-JB", ENDITEM, 
		"Name=flightID", "Value=2514530421-20247127-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-20777-JB", ENDITEM, 
		"Name=flightID", "Value=2514530421-21785589-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-22315-JB", ENDITEM, 
		"Name=flightID", "Value=2514530421-23324050-JB", ENDITEM, 
		"Name=removeFlights.x", "Value=84", ENDITEM, 
		"Name=removeFlights.y", "Value=11", ENDITEM, 
		"Name=.cgifields", "Value=11", ENDITEM, 
		"Name=.cgifields", "Value=21", ENDITEM, 
		"Name=.cgifields", "Value=7", ENDITEM, 
		"Name=.cgifields", "Value=26", ENDITEM, 
		"Name=.cgifields", "Value=17", ENDITEM, 
		"Name=.cgifields", "Value=2", ENDITEM, 
		"Name=.cgifields", "Value=22", ENDITEM, 
		"Name=.cgifields", "Value=1", ENDITEM, 
		"Name=.cgifields", "Value=18", ENDITEM, 
		"Name=.cgifields", "Value=30", ENDITEM, 
		"Name=.cgifields", "Value=23", ENDITEM, 
		"Name=.cgifields", "Value=16", ENDITEM, 
		"Name=.cgifields", "Value=13", ENDITEM, 
		"Name=.cgifields", "Value=29", ENDITEM, 
		"Name=.cgifields", "Value=27", ENDITEM, 
		"Name=.cgifields", "Value=25", ENDITEM, 
		"Name=.cgifields", "Value=6", ENDITEM, 
		"Name=.cgifields", "Value=28", ENDITEM, 
		"Name=.cgifields", "Value=3", ENDITEM, 
		"Name=.cgifields", "Value=9", ENDITEM, 
		"Name=.cgifields", "Value=12", ENDITEM, 
		"Name=.cgifields", "Value=20", ENDITEM, 
		"Name=.cgifields", "Value=14", ENDITEM, 
		"Name=.cgifields", "Value=15", ENDITEM, 
		"Name=.cgifields", "Value=8", ENDITEM, 
		"Name=.cgifields", "Value=4", ENDITEM, 
		"Name=.cgifields", "Value=24", ENDITEM, 
		"Name=.cgifields", "Value=19", ENDITEM, 
		"Name=.cgifields", "Value=10", ENDITEM, 
		"Name=.cgifields", "Value=5", ENDITEM, 
		LAST);

	lr_end_transaction("itinerary cancel",LR_AUTO);

	lr_think_time(18);

	lr_start_transaction("itinerary cancel all");

	web_submit_data("itinerary.pl_2", 
		"Action=http://localhost:1080/cgi-bin/itinerary.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/itinerary.pl", 
		"Snapshot=t114.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=flightID", "Value=251445276-924758-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-1546-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-2315-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-3085-JB", ENDITEM, 
		"Name=flightID", "Value=2514530421-4093281-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-4623-JB", ENDITEM, 
		"Name=flightID", "Value=2514622660-6032600-JB", ENDITEM, 
		"Name=flightID", "Value=25146569-621-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-6931-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-7700-JB", ENDITEM, 
		"Name=flightID", "Value=2514530421-8708666-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-9239-JB", ENDITEM, 
		"Name=flightID", "Value=2514530421-10247127-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-10777-JB", ENDITEM, 
		"Name=flightID", "Value=2514530421-11785589-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-12315-JB", ENDITEM, 
		"Name=flightID", "Value=2514530421-13324050-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-13854-JB", ENDITEM, 
		"Name=flightID", "Value=2514530421-14862512-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-15392-JB", ENDITEM, 
		"Name=flightID", "Value=2514530421-16400973-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-16931-JB", ENDITEM, 
		"Name=flightID", "Value=2514530421-17939435-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-18469-JB", ENDITEM, 
		"Name=flightID", "Value=2514530421-19477897-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-20008-JB", ENDITEM, 
		"Name=flightID", "Value=2514530421-21016358-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-21546-JB", ENDITEM, 
		"Name=flightID", "Value=2514530421-22554820-JB", ENDITEM, 
		"Name=removeAllFlights.x", "Value=32", ENDITEM, 
		"Name=removeAllFlights.y", "Value=5", ENDITEM, 
		"Name=.cgifields", "Value=11", ENDITEM, 
		"Name=.cgifields", "Value=21", ENDITEM, 
		"Name=.cgifields", "Value=7", ENDITEM, 
		"Name=.cgifields", "Value=26", ENDITEM, 
		"Name=.cgifields", "Value=17", ENDITEM, 
		"Name=.cgifields", "Value=2", ENDITEM, 
		"Name=.cgifields", "Value=22", ENDITEM, 
		"Name=.cgifields", "Value=1", ENDITEM, 
		"Name=.cgifields", "Value=18", ENDITEM, 
		"Name=.cgifields", "Value=23", ENDITEM, 
		"Name=.cgifields", "Value=16", ENDITEM, 
		"Name=.cgifields", "Value=13", ENDITEM, 
		"Name=.cgifields", "Value=29", ENDITEM, 
		"Name=.cgifields", "Value=27", ENDITEM, 
		"Name=.cgifields", "Value=25", ENDITEM, 
		"Name=.cgifields", "Value=6", ENDITEM, 
		"Name=.cgifields", "Value=28", ENDITEM, 
		"Name=.cgifields", "Value=3", ENDITEM, 
		"Name=.cgifields", "Value=9", ENDITEM, 
		"Name=.cgifields", "Value=12", ENDITEM, 
		"Name=.cgifields", "Value=20", ENDITEM, 
		"Name=.cgifields", "Value=14", ENDITEM, 
		"Name=.cgifields", "Value=15", ENDITEM, 
		"Name=.cgifields", "Value=8", ENDITEM, 
		"Name=.cgifields", "Value=4", ENDITEM, 
		"Name=.cgifields", "Value=24", ENDITEM, 
		"Name=.cgifields", "Value=19", ENDITEM, 
		"Name=.cgifields", "Value=10", ENDITEM, 
		"Name=.cgifields", "Value=5", ENDITEM, 
		LAST);

	lr_end_transaction("itinerary cancel all",LR_AUTO);

	lr_start_transaction("sign off");

	web_add_header("DNT", 
		"1");

	web_add_header("Sec-Fetch-Mode", 
		"nested-navigate");

	web_add_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	lr_think_time(23);

	web_url("welcome.pl_3", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?signOff=1", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=itinerary", 
		"Snapshot=t115.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("sign off",LR_AUTO);

	lr_end_transaction("4_Script",LR_AUTO);

	return 0;
}