ForthScript()
{

	web_set_sockets_option("SSL_VERSION", "2&3");

	web_reg_save_param_ex(
        "ParamName=userSession_1",
        "LB=<input type=\"hidden\" name=\"userSession\" value=\"",
        "RB=\"",
        SEARCH_FILTERS,
        "IgnoreRedirections=off",
        "Scope=Body",
        "RequestUrl=*",
        LAST);
	
/*Correlation comment - Do not change!  Original value='127661.869906845zfzzzAHptDDDDDDDDQDQQpzttz' Name ='userSession' Type ='ResponseBased'*/
//	web_reg_save_param_attrib(
//		"ParamName=userSession",
//		"TagName=input",
//		"Extract=value",
//		"Name=userSession",
//		"Type=hidden",
//		SEARCH_FILTERS,
//		"IgnoreRedirections=No",
//		"RequestUrl=*/nav.pl*",
//		LAST);

	web_url("welcome.pl", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?signOff=true", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/WebTours/", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(5);

	lr_start_transaction("4_Script");

	lr_start_transaction("LOGIN");

	web_add_header("Origin", 
		"http://localhost:1080");

	lr_think_time(5);

	web_submit_data("login.pl",
		"Action=http://localhost:1080/cgi-bin/login.pl",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/html",
		"Referer=http://localhost:1080/cgi-bin/nav.pl?in=home",
		"Snapshot=t16.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=userSession", "Value={userSession_1}", ENDITEM,
		"Name=username", "Value=jojo", ENDITEM,
		"Name=password", "Value=bean", ENDITEM,
		"Name=login.x", "Value=12", ENDITEM,
		"Name=login.y", "Value=5", ENDITEM,
		"Name=JSFormSubmit", "Value=off", ENDITEM,
		LAST);

	lr_end_transaction("LOGIN",LR_AUTO);

	lr_start_transaction("home");

	lr_think_time(5);

	web_url("Home Button", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?page=menus", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=home", 
		"Snapshot=t111.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("home",LR_AUTO);

	lr_start_transaction("itinerary");

	lr_think_time(5);

	web_url("welcome.pl_2", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?page=itinerary", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=home", 
		"Snapshot=t112.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("itinerary",LR_AUTO);

	lr_start_transaction("itinerary cancel");

	lr_think_time(5);

	web_submit_data("itinerary.pl", 
		"Action=http://localhost:1080/cgi-bin/itinerary.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/itinerary.pl", 
		"Snapshot=t113.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=1", "Value=on", ENDITEM, 
		"Name=flightID", "Value=251445271-793-JB", ENDITEM, 
		"Name=flightID", "Value=251445276-1693988-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-2315-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-3085-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-3854-JB", ENDITEM, 
		"Name=flightID", "Value=2514530421-4862512-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-5392-JB", ENDITEM, 
		"Name=flightID", "Value=2514622660-6801831-JB", ENDITEM, 
		"Name=flightID", "Value=25146569-698-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-7700-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-8469-JB", ENDITEM, 
		"Name=flightID", "Value=2514530421-9477897-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-10008-JB", ENDITEM, 
		"Name=flightID", "Value=2514530421-11016358-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-11546-JB", ENDITEM, 
		"Name=flightID", "Value=2514530421-12554820-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-13085-JB", ENDITEM, 
		"Name=flightID", "Value=2514530421-14093281-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-14623-JB", ENDITEM, 
		"Name=flightID", "Value=2514530421-15631743-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-16162-JB", ENDITEM, 
		"Name=flightID", "Value=2514530421-17170204-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-17700-JB", ENDITEM, 
		"Name=flightID", "Value=2514530421-18708666-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-19239-JB", ENDITEM, 
		"Name=flightID", "Value=2514530421-20247127-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-20777-JB", ENDITEM, 
		"Name=flightID", "Value=2514530421-21785589-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-22315-JB", ENDITEM, 
		"Name=flightID", "Value=2514530421-23324050-JB", ENDITEM, 
		"Name=removeFlights.x", "Value=84", ENDITEM, 
		"Name=removeFlights.y", "Value=11", ENDITEM, 
		"Name=.cgifields", "Value=11", ENDITEM, 
		"Name=.cgifields", "Value=21", ENDITEM, 
		"Name=.cgifields", "Value=7", ENDITEM, 
		"Name=.cgifields", "Value=26", ENDITEM, 
		"Name=.cgifields", "Value=17", ENDITEM, 
		"Name=.cgifields", "Value=2", ENDITEM, 
		"Name=.cgifields", "Value=22", ENDITEM, 
		"Name=.cgifields", "Value=1", ENDITEM, 
		"Name=.cgifields", "Value=18", ENDITEM, 
		"Name=.cgifields", "Value=30", ENDITEM, 
		"Name=.cgifields", "Value=23", ENDITEM, 
		"Name=.cgifields", "Value=16", ENDITEM, 
		"Name=.cgifields", "Value=13", ENDITEM, 
		"Name=.cgifields", "Value=29", ENDITEM, 
		"Name=.cgifields", "Value=27", ENDITEM, 
		"Name=.cgifields", "Value=25", ENDITEM, 
		"Name=.cgifields", "Value=6", ENDITEM, 
		"Name=.cgifields", "Value=28", ENDITEM, 
		"Name=.cgifields", "Value=3", ENDITEM, 
		"Name=.cgifields", "Value=9", ENDITEM, 
		"Name=.cgifields", "Value=12", ENDITEM, 
		"Name=.cgifields", "Value=20", ENDITEM, 
		"Name=.cgifields", "Value=14", ENDITEM, 
		"Name=.cgifields", "Value=15", ENDITEM, 
		"Name=.cgifields", "Value=8", ENDITEM, 
		"Name=.cgifields", "Value=4", ENDITEM, 
		"Name=.cgifields", "Value=24", ENDITEM, 
		"Name=.cgifields", "Value=19", ENDITEM, 
		"Name=.cgifields", "Value=10", ENDITEM, 
		"Name=.cgifields", "Value=5", ENDITEM, 
		LAST);

	lr_end_transaction("itinerary cancel",LR_AUTO);

	lr_start_transaction("itinerary cancel all");

	lr_think_time(5);

	web_submit_data("itinerary.pl_2",
		"Action=http://localhost:1080/cgi-bin/itinerary.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/itinerary.pl", 
		"Snapshot=t114.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=flightID", "Value=251445276-924758-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-1546-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-2315-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-3085-JB", ENDITEM, 
		"Name=flightID", "Value=2514530421-4093281-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-4623-JB", ENDITEM, 
		"Name=flightID", "Value=2514622660-6032600-JB", ENDITEM, 
		"Name=flightID", "Value=25146569-621-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-6931-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-7700-JB", ENDITEM, 
		"Name=flightID", "Value=2514530421-8708666-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-9239-JB", ENDITEM, 
		"Name=flightID", "Value=2514530421-10247127-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-10777-JB", ENDITEM, 
		"Name=flightID", "Value=2514530421-11785589-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-12315-JB", ENDITEM, 
		"Name=flightID", "Value=2514530421-13324050-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-13854-JB", ENDITEM, 
		"Name=flightID", "Value=2514530421-14862512-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-15392-JB", ENDITEM, 
		"Name=flightID", "Value=2514530421-16400973-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-16931-JB", ENDITEM, 
		"Name=flightID", "Value=2514530421-17939435-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-18469-JB", ENDITEM, 
		"Name=flightID", "Value=2514530421-19477897-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-20008-JB", ENDITEM, 
		"Name=flightID", "Value=2514530421-21016358-JB", ENDITEM, 
		"Name=flightID", "Value=251467855-21546-JB", ENDITEM, 
		"Name=flightID", "Value=2514530421-22554820-JB", ENDITEM, 
		"Name=removeAllFlights.x", "Value=32", ENDITEM, 
		"Name=removeAllFlights.y", "Value=5", ENDITEM, 
		"Name=.cgifields", "Value=11", ENDITEM, 
		"Name=.cgifields", "Value=21", ENDITEM, 
		"Name=.cgifields", "Value=7", ENDITEM, 
		"Name=.cgifields", "Value=26", ENDITEM, 
		"Name=.cgifields", "Value=17", ENDITEM, 
		"Name=.cgifields", "Value=2", ENDITEM, 
		"Name=.cgifields", "Value=22", ENDITEM, 
		"Name=.cgifields", "Value=1", ENDITEM, 
		"Name=.cgifields", "Value=18", ENDITEM, 
		"Name=.cgifields", "Value=23", ENDITEM, 
		"Name=.cgifields", "Value=16", ENDITEM, 
		"Name=.cgifields", "Value=13", ENDITEM, 
		"Name=.cgifields", "Value=29", ENDITEM, 
		"Name=.cgifields", "Value=27", ENDITEM, 
		"Name=.cgifields", "Value=25", ENDITEM, 
		"Name=.cgifields", "Value=6", ENDITEM, 
		"Name=.cgifields", "Value=28", ENDITEM, 
		"Name=.cgifields", "Value=3", ENDITEM, 
		"Name=.cgifields", "Value=9", ENDITEM, 
		"Name=.cgifields", "Value=12", ENDITEM, 
		"Name=.cgifields", "Value=20", ENDITEM, 
		"Name=.cgifields", "Value=14", ENDITEM, 
		"Name=.cgifields", "Value=15", ENDITEM, 
		"Name=.cgifields", "Value=8", ENDITEM, 
		"Name=.cgifields", "Value=4", ENDITEM, 
		"Name=.cgifields", "Value=24", ENDITEM, 
		"Name=.cgifields", "Value=19", ENDITEM, 
		"Name=.cgifields", "Value=10", ENDITEM, 
		"Name=.cgifields", "Value=5", ENDITEM, 
		LAST);

	lr_end_transaction("itinerary cancel all",LR_AUTO);

	lr_start_transaction("sign off");

	lr_think_time(5);

	web_url("welcome.pl_3", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?signOff=1", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=itinerary", 
		"Snapshot=t115.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("sign off",LR_AUTO);

	lr_end_transaction("4_Script",LR_AUTO);

	return 0;
}